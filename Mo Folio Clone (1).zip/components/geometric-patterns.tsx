"use client"

export default function GeometricPatterns() {
  // Disable the component completely
  return null
}
